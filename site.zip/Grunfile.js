module.exports = function(grunt) {
	require('jit-grunt')(grunt);
// автоматичне завантаження модулів
	grunt.initConfig({
		less: {
// назва завдання
			development: {
// режим розробки
				files: {
					"css/styles.css": "css/styles.less"
// компілювати css/styles.css з css/styles.less
				}
			}
		},
		watch: {
// автоматично запускати
			styles: {
// для файлів стилів
				files: ['css/**/*.less'],
// якщо відбулися зміни у файлах .less у директорії /css і її субдиректоріях
				tasks: ['less'],
// визначена вище назва завдання
				options: {
					nospawn: true
				}
			}
		}
	});
	grunt.registerTask('default', ['less', 'watch']);
};